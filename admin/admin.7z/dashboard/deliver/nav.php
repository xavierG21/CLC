<ul id="main-menu" class="">
			
    <li class="active opened active"><a href="index.php"><i class="entypo-gauge"></i><span>Home</span></a></li>
	

	
	
	
		<li><a href="category.php"><i class="entypo-tag"></i><span>Delivery</span></a>
		<ul>
			
			<li class="active">
				<a href="view_pay.php"><span>View Delivery</span></a></li>
			

			
		</ul>
	</li>
	
	
		<li><a href="#"><i class="entypo-paper-plane"></i><span>Updated Delivery</span></a>

		<ul>
			<li class="active">
				<a href="view_delivery.php"><span>View Delivered</span></a></li>

			
		</ul>
		
			
	

	<li><a href="more-userprofile.php"><i class="entypo-user"></i><span>Profile</span></a></li>

	<li><a href="logout.php"><i class="entypo-logout"></i><span>Logout</span></a></li>

</ul>	