<!doctype html>
<!--[if IE 9 ]><html class="ie9" lang="en"><![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html lang="en"><!--<![endif]-->
	<head>
		<title></title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<!--meta info-->
		<meta name="author" content=''>
		<meta name="keywords" content=''>
		<meta name="description" content=''>
		<link rel="icon" type="../image/ico" href="../images/fav.ico">
		<!--stylesheet include-->
		<link rel="stylesheet" type="text/css" media="all" href="../../../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" media="all" href="../../../css/camera.css">
		<link rel="stylesheet" type="text/css" media="all" href="../../../css/owl.carousel.css">
		<link rel="stylesheet" type="text/css" media="all" href="../../../css/owl.transitions.css">
		<link rel="stylesheet" type="text/css" media="all" href="../../../css/jquery.custom-scrollbar.css">
		<link rel="stylesheet" type="text/css" media="all" href="../../../css/style.css">
		<!--font include-->
		<link href="../css/font-awesome.min.css" rel="stylesheet">
	</head>
	<body>
	<div class="boxed_layout relative w_xs_auto">
			<!--[if (lt IE 9) | IE 9]>
				<div style="background:#fff;padding:8px 0 10px;">
				<div class="container" style="width:1170px;"><div class="row wrapper"><div class="clearfix" style="padding:9px 0 0;float:left;width:83%;"><i class="fa fa-exclamation-triangle scheme_color f_left m_right_10" style="font-size:25px;color:#e74c3c;"></i><b style="color:#e74c3c;">Attention! This page may not display correctly.</b> <b>You are using an outdated version of Internet Explorer. For a faster, safer browsing experience.</b></div><div class="t_align_r" style="float:left;width:16%;"><a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode" class="button_type_4 r_corners bg_scheme_color color_light d_inline_b t_align_c" target="_blank" style="margin-bottom:2px;">Update Now!</a></div></div></div></div>
			<![endif]-->
			<!--markup header-->
			<header role="banner">
				<!--header top part-->
				<section class="h_top_part">
					<div class="container">
						<div class="row clearfix">
							<div class="col-lg-4 col-md-4 col-sm-5 t_xs_align_c">
								<p class="f_size_small">Welcome visitor can you	<a href="#" data-popup="#login_popup">Log In</a> or <a href="#">Create an Account</a> </p>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-2 t_align_c t_xs_align_c">
								<p class="f_size_small">Call us toll free: <b class="color_dark">(123) 456-7890</b></p>
							</div>
							<nav class="col-lg-4 col-md-4 col-sm-5 t_align_r t_xs_align_c">
								<ul class="d_inline_b horizontal_list clearfix f_size_small users_nav">
									<li><a href="#" class="default_t_color">My Account</a></li>
									<li><a href="#" class="default_t_color">Orders List</a></li>
									<li><a href="#" class="default_t_color">Wishlist</a></li>
									<li><a href="#" class="default_t_color">Checkout</a></li>
								</ul>
							</nav>
						</div>
					</div>
				</section>
				<!--header bottom part-->
				<section class="h_bot_part container">
					<div class="clearfix row">
						
						
						<div class="col-sm-1 col-sm-1 t_xs_align_c">
						
							<a href="index.html" class="logo m_xs_bottom_15 d_xs_inline_b">
								<img src="../../../images/big_clc.png" alt="">
							</a>
							

						</div>

						<div class=" m_xs_bottom_15 d_xs_inline_b">						
						<h1>CENTRAL LUMBER CORPORATION</h1>
						</div>
						
						
					</div>
				</section>
				</header>
<script src="../js/jquery-2.1.0.min.js"></script>
		<script src="../js/jquery-migrate-1.2.1.min.js"></script>
		<script src="../js/retina.js"></script>
		<script src="../js/camera.min.js"></script>
		<script src="../js/jquery.easing.1.3.js"></script>
		<script src="../js/waypoints.min.js"></script>
		<script src="../js/jquery.isotope.min.js"></script>
		<script src="../js/owl.carousel.min.js"></script>
		<script src="../js/jquery.tweet.min.js"></script>
		<script src="../js/jquery.custom-scrollbar.js"></script>
		<script src="../js/scripts.js"></script>
<script type="text/javascript" src="http://s7.addthis.com/js/300/addthis_widget.js#pubid=xa-5306f8f674bfda4c"></script>
	</body>
</html>