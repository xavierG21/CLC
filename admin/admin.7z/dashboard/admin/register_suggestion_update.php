<?php
require 'db_conn.php';
//var_dump($_POST);	
page_protect();
if (isset($_POST['s_id'])) {
    
    
	

   // $date      = $_POST['date'];
    $s_id       = ($_POST['s_id']);
	$s_name = ($_POST['s_name']);
    $s_desc       = ($_POST['s_desc']);
	//$p_price	   = $_POST['p_price']; 
	
   
    $filetmp = $_FILES["file_img"]["tmp_name"];
		$filename= $_FILES["file_img"]["name"];
		$filetype=$_FILES["file_img"]["type"];
		$filepath="../../../photo/".$filename;


		

		move_uploaded_file($filetmp, $filepath);
		
		
    
    
    mysqli_query($con, "UPDATE suggestion SET id='$s_id', name='$s_name', description='$s_desc',image='$filename'WHERE id='$s_id'");
    echo "<head><script>alert('Product Edited');</script></head></html>";
	echo "<meta http-equiv='refresh' content='0; url=view_products.php'>";
	//echo "<meta http-equiv='refresh' content='0; url=view_reg.php'>";
} else {
    echo "<head><script>alert('Profile NOT Updated, Check Again');</script></head></html>";
    //echo "<meta http-equiv='refresh' content='0; url=view_reg.php'>";
    
}
?>
