<?php
require("db_conn.php");
var_dump($_POST);
if (isset($_POST['p_id'])) {
//product_cat
$p_id = ($_POST['p_id']);



$filetmp2 = $_FILES["file_img2"]["tmp_name"];
		$filename2= $_FILES["file_img2"]["name"];
		$filetype2=$_FILES["file_img2"]["type"];
		$filepath2="../../../photo/".$filename2;

		move_uploaded_file($filetmp2, $filepath2);

$filetmp3 = $_FILES["file_img3"]["tmp_name"];
		$filename3= $_FILES["file_img3"]["name"];
		$filetype3=$_FILES["file_img3"]["type"];
		$filepath3="../../../photo/".$filename3;

		move_uploaded_file($filetmp3, $filepath3);

$filetmp4 = $_FILES["file_img4"]["tmp_name"];
		$filename4= $_FILES["file_img4"]["name"];
		$filetype4=$_FILES["file_img4"]["type"];
		$filepath4="../../../photo/".$filename4;

		move_uploaded_file($filetmp4, $filepath4);				
								
				
								

	 	

mysqli_query($con, "UPDATE products SET color_one='$filename2',color_two='$filename3', color_three='$filename4' WHERE id='$p_id'");
		
		

} else {
    //echo "<head><script>alert('Profile NOT Updated, Check Again');</script></head></html>";
    //echo "<meta http-equiv='refresh' content='0; url=view_reg.php'>";
    
}		
	//$dir="upload/";
	//$target = "image/".basename($_FILES['image']['name']);

	//if(!is_dir($dir)) {
	//echo "Create Done";
	//mkdir($dir,"0777",true);

	//$image = $_FILES['image']['image'];

	//$query3="INSERT INTO product_details(product_id, description, size, srp,img)
	//VALUES ('$p_id','$desc','$s','$p','$filename')";

	//$result3 = mysqli_query($con, $query3);
	//echo "<html><head><script>alert('Product Added');</script></head></html>";
	//echo "<meta http-equiv='refresh' content='0; url=view_products.php'>";

	
?>